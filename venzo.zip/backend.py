
class Login:
    def __init__(self,bro_obj,uname,upass):
        self.bro_obj=bro_obj
        self.uname=uname
        self.upass=upass
